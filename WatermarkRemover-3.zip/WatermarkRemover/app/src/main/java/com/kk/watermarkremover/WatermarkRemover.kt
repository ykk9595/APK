package com.kk.watermarkremover

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

/**
 * 移除圖片角落浮水印的核心邏輯。
 * 概念跟 remove_watermark.py 一樣：
 *   1. 在指定角落切出一小塊區域
 *   2. 用亮/暗閾值找出浮水印文字，做出遮罩 (mask)
 *   3. 用 OpenCV Photo.inpaint 把遮罩區域用周圍像素補回去
 */
object WatermarkRemover {

    enum class Corner { BOTTOM_RIGHT, BOTTOM_LEFT, TOP_RIGHT, TOP_LEFT }

    /**
     * @param src 原始 Bitmap
     * @param corner 浮水印所在角落
     * @param regionWRatio 區域寬度佔整張圖寬度的比例 (0~1)
     * @param regionHRatio 區域高度佔整張圖高度的比例 (0~1)
     * @param inpaintRadius 修復半徑，數字越大修得越「糊」但越乾淨
     */
    fun process(
        src: Bitmap,
        corner: Corner,
        regionWRatio: Double,
        regionHRatio: Double,
        inpaintRadius: Double = 5.0
    ): Bitmap {
        val srcMat = Mat()
        Utils.bitmapToMat(src, srcMat) // RGBA
        val bgr = Mat()
        Imgproc.cvtColor(srcMat, bgr, Imgproc.COLOR_RGBA2BGR)

        val w = bgr.cols()
        val h = bgr.rows()
        val rw = (w * regionWRatio).toInt().coerceIn(1, w)
        val rh = (h * regionHRatio).toInt().coerceIn(1, h)

        val roiRect = when (corner) {
            Corner.BOTTOM_RIGHT -> Rect(w - rw, h - rh, rw, rh)
            Corner.BOTTOM_LEFT -> Rect(0, h - rh, rw, rh)
            Corner.TOP_RIGHT -> Rect(w - rw, 0, rw, rh)
            Corner.TOP_LEFT -> Rect(0, 0, rw, rh)
        }

        val region = Mat(bgr, roiRect)
        val gray = Mat()
        Imgproc.cvtColor(region, gray, Imgproc.COLOR_BGR2GRAY)

        // 亮色文字 (白字) 用高閾值抓；暗色文字 (黑字) 用低閾值抓，兩者取聯集
        val brightMask = Mat()
        Imgproc.threshold(gray, brightMask, 200.0, 255.0, Imgproc.THRESH_BINARY)
        val darkMask = Mat()
        Imgproc.threshold(gray, darkMask, 50.0, 255.0, Imgproc.THRESH_BINARY_INV)

        val regionMask = Mat()
        Core.bitwise_or(brightMask, darkMask, regionMask)

        // 膨脹，涵蓋文字邊緣的半透明像素
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0))
        Imgproc.dilate(regionMask, regionMask, kernel, org.opencv.core.Point(-1.0, -1.0), 2)

        // 把小遮罩貼回跟原圖一樣大的全尺寸遮罩
        val fullMask = Mat.zeros(bgr.size(), org.opencv.core.CvType.CV_8UC1)
        regionMask.copyTo(Mat(fullMask, roiRect))

        val result = Mat()
        Imgproc.inpaint(bgr, fullMask, result, inpaintRadius, Imgproc.INPAINT_TELEA)

        val resultRgba = Mat()
        Imgproc.cvtColor(result, resultRgba, Imgproc.COLOR_BGR2RGBA)

        val outBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(resultRgba, outBitmap)

        // 釋放 native 記憶體
        listOf(srcMat, bgr, region, gray, brightMask, darkMask, regionMask, fullMask, result, resultRgba)
            .forEach { it.release() }

        return outBitmap
    }
}
