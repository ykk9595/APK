package com.kk.watermarkremover

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.kk.watermarkremover.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.opencv.android.OpenCVLoader
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var originalBitmap: Bitmap? = null
    private var resultBitmap: Bitmap? = null

    private var regionWRatio = 0.20
    private var regionHRatio = 0.05
    private var corner = WatermarkRemover.Corner.BOTTOM_RIGHT

    private val cornerLabels = listOf("右下角", "左下角", "右上角", "左上角")
    private val cornerValues = listOf(
        WatermarkRemover.Corner.BOTTOM_RIGHT,
        WatermarkRemover.Corner.BOTTOM_LEFT,
        WatermarkRemover.Corner.TOP_RIGHT,
        WatermarkRemover.Corner.TOP_LEFT
    )

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) loadImage(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!OpenCVLoader.initLocal()) {
            Toast.makeText(this, "OpenCV 初始化失敗", Toast.LENGTH_LONG).show()
        }

        setupCornerSpinner()
        setupSeekBars()

        binding.btnPickImage.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        binding.btnProcess.setOnClickListener {
            runWatermarkRemoval()
        }

        binding.btnSave.setOnClickListener {
            saveToGallery()
        }

        binding.btnShare.setOnClickListener {
            shareResult()
        }
    }

    private fun setupCornerSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, cornerLabels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerCorner.adapter = adapter
        binding.spinnerCorner.setSelection(0)
        binding.spinnerCorner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long
                ) {
                    corner = cornerValues[position]
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
    }

    private fun setupSeekBars() {
        binding.seekWidth.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val p = progress.coerceAtLeast(1)
                regionWRatio = p / 100.0
                binding.labelWidth.text = "區域寬度比例：$p%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekHeight.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val p = progress.coerceAtLeast(1)
                regionHRatio = p / 100.0
                binding.labelHeight.text = "區域高度比例：$p%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun loadImage(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri)
            val bmp = BitmapFactory.decodeStream(input)
            input?.close()
            if (bmp == null) {
                Toast.makeText(this, "讀取圖片失敗", Toast.LENGTH_SHORT).show()
                return
            }
            originalBitmap = bmp
            resultBitmap = null
            binding.imagePreview.setImageBitmap(bmp)
            binding.placeholderText.visibility = View.GONE
            binding.btnProcess.isEnabled = true
            binding.btnSave.isEnabled = false
            binding.btnShare.isEnabled = false
        } catch (e: Exception) {
            Log.e("MainActivity", "loadImage failed", e)
            Toast.makeText(this, "讀取圖片失敗：${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun runWatermarkRemoval() {
        val src = originalBitmap ?: return
        setLoading(true)

        CoroutineScope(Dispatchers.Main).launch {
            try {
                val output = withContext(Dispatchers.Default) {
                    WatermarkRemover.process(
                        src = src,
                        corner = corner,
                        regionWRatio = regionWRatio,
                        regionHRatio = regionHRatio
                    )
                }
                resultBitmap = output
                binding.imagePreview.setImageBitmap(output)
                binding.btnSave.isEnabled = true
                binding.btnShare.isEnabled = true
                Toast.makeText(this@MainActivity, "處理完成", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Log.e("MainActivity", "process failed", e)
                Toast.makeText(this@MainActivity, "處理失敗：${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                setLoading(false)
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnProcess.isEnabled = !loading && originalBitmap != null
        binding.btnPickImage.isEnabled = !loading
    }

    private fun saveToGallery() {
        val bmp = resultBitmap ?: return
        try {
            val filename = "watermark_removed_${System.currentTimeMillis()}.png"
            val resolver = contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/WatermarkRemover")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out ->
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
                Toast.makeText(this, "已儲存到相簿 / Pictures/WatermarkRemover", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "儲存失敗", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "saveToGallery failed", e)
            Toast.makeText(this, "儲存失敗：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareResult() {
        val bmp = resultBitmap ?: return
        try {
            val cacheDir = File(cacheDir, "shared")
            cacheDir.mkdirs()
            val file = File(cacheDir, "watermark_removed.png")
            FileOutputStream(file).use { out ->
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(intent, "分享圖片"))
        } catch (e: Exception) {
            Log.e("MainActivity", "shareResult failed", e)
            Toast.makeText(this, "分享失敗：${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
